package Ej1;

public class DirectorEmpleado implements Empleados {

	@Override
	public String getTareas() {

		return "Gestionar la plantilla de la empresa";
	}

}
