package Ej1;

public class JefeEmpleado implements Empleados{
	
	public String getTareas() {
		
		return "Gestiono las cuestiones relativas a mis empleados de sección";
		
	}
	
}