package Ej1;

public class UsoEmpleados {

	public static void main(String[] args) {
		// Creación de obejtos de tipo Empleado
		
		Empleados Empleado1 = new DirectorEmpleado();
		
		// Uso de los objetos creados

		System.out.println(Empleado1.getTareas());
	}

}